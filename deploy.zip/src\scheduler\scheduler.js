import config from '../core/config.js';
import logger from '../core/logger.js';
import {
  addJob, getNextJob, updateJob, getStats,
  addUpload, getUploads, updateUpload, getAccounts,
  getVideo,
} from '../core/database.js';

/**
 * Scheduler - manages job queue, rate limiting, and execution
 */
export class Scheduler {
  constructor() {
    this.isRunning = false;
    this.isPaused = false;
    this._timer = null;
    this._handlers = {};
    this.currentJob = null;
  }

  /**
   * Register a job handler
   */
  registerHandler(type, handler) {
    this._handlers[type] = handler;
  }

  /**
   * Add a job to the queue
   */
  enqueue(type, payload, priority = 0) {
    const result = addJob(type, payload, priority);
    logger.info(`Job enqueued: ${type} (id: ${result.lastInsertRowid})`);
    return result.lastInsertRowid;
  }

  /**
   * Start processing jobs
   */
  start() {
    if (this.isRunning) {
      logger.warn('Scheduler already running');
      return;
    }

    this.isRunning = true;
    this.isPaused = false;
    logger.info('Scheduler started');
    this._processNext();
  }

  /**
   * Stop processing
   */
  stop() {
    this.isRunning = false;
    if (this._timer) clearTimeout(this._timer);
    logger.info('Scheduler stopped');
  }

  /**
   * Pause processing (finish current, don't start new)
   */
  pause() {
    this.isPaused = true;
    logger.info('Scheduler paused');
  }

  /**
   * Resume processing
   */
  resume() {
    this.isPaused = false;
    logger.info('Scheduler resumed');
    this._processNext();
  }

  /**
   * Get scheduler status
   */
  getStatus() {
    const stats = getStats();
    return {
      isRunning: this.isRunning,
      isPaused: this.isPaused,
      currentJob: this.currentJob,
      ...stats,
    };
  }

  // Process next job in queue
  async _processNext() {
    if (!this.isRunning || this.isPaused) return;

    // Check rate limits
    const stats = getStats();
    if (stats.todayUploads >= config.maxUploadsPerDay) {
      logger.warn(`Daily upload limit reached (${config.maxUploadsPerDay}). Waiting until tomorrow.`);
      // Schedule check for midnight
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);
      const delay = tomorrow - now;
      this._timer = setTimeout(() => this._processNext(), delay);
      return;
    }

    const job = getNextJob();
    if (!job) {
      // No jobs, check again later
      this._timer = setTimeout(() => this._processNext(), 10000); // 10 sec
      return;
    }

    const handler = this._handlers[job.type];
    if (!handler) {
      logger.error(`No handler for job type: ${job.type}`);
      updateJob(job.id, { status: 'failed', error_message: 'No handler registered' });
      this._processNext();
      return;
    }

    // Execute job
    this.currentJob = job;
    updateJob(job.id, { status: 'running', started_at: new Date().toISOString() });
    logger.info(`Processing job #${job.id}: ${job.type}`);

    try {
      const payload = JSON.parse(job.payload);
      const result = await handler(payload);

      updateJob(job.id, {
        status: 'completed',
        result: JSON.stringify(result || {}),
        completed_at: new Date().toISOString(),
      });
      logger.info(`Job #${job.id} completed`);
    } catch (error) {
      const retryCount = job.retry_count + 1;
      if (retryCount < job.max_retries) {
        logger.warn(`Job #${job.id} failed (attempt ${retryCount}/${job.max_retries}): ${error.message}`);
        updateJob(job.id, {
          status: 'pending',
          retry_count: retryCount,
          error_message: error.message,
        });
      } else {
        logger.error(`Job #${job.id} permanently failed: ${error.message}`);
        updateJob(job.id, {
          status: 'failed',
          retry_count: retryCount,
          error_message: error.message,
          completed_at: new Date().toISOString(),
        });
      }
    }

    this.currentJob = null;

    // Rate limit delay between uploads
    const delayMs = config.uploadIntervalMinutes * 60 * 1000;
    logger.debug(`Next job in ${config.uploadIntervalMinutes} minutes`);
    this._timer = setTimeout(() => this._processNext(), delayMs);
  }
}

export default Scheduler;
